Terms and Conditions of Commercial License.

The following agreement applies to commercial licenses purchased at this website (defharo.com).
Please read the following terms and conditions carefully before using this font. Use, transfer, distribution or installation of this source indicates acceptance of this agreement.

For questions, contact Fernando Haro: fernando@defharo.com

The commercial license fonts developed by Fernando Haro is intended for a single user and can use on their personal computers for up to three and a superior work in any business environment where the font used. In no event sources can be used for more than a company with a single license.

In case you need a license for a computer network please contact the author.

All components accompanying the file download are the property of Fernando Haro and can not be disassembled, modified , used , distributed or copied in any way.

This Agreement constitutes the complete statement of the agreement between the parties on the matter, and merges and supersedes all other or prior understandings, purchase orders, agreements and arrangements.

This Agreement shall be governed by the laws of Spain. Fernando Haro owns the copyright of sources , all derivatives, the name and the accompanying materials are the exclusive property of Fernando Haro.

You may not sell, rent, lease, transfer, modify, translate, reverse engineer, decompile, disassemble or create jobs with commercial typefaces.

========================================

T�rminos y Condiciones para fuentes comerciales.

Este acuerdo se aplica a la licencia comercial comprada en mi web (defharo.com).
Por favor, lea los siguientes t�rminos y condiciones cuidadosamente antes de utilizar esta fuente. Su uso, transferencia, distribuci�n o instalaci�n de esta fuente indica la aceptaci�n de este acuerdo.

Para cualquier duda, p�ngase en contacto con Fernando Haro: fernando@defharo.com

La licencia comercial de las fuentes desarrolladas por Fernando Haro es exclusivamente para un s�lo usuario y puede utilizarla en sus ordenadores personales hasta un m�ximo de tres y en cualquier trabajo superior de �mbito comercial donde se use el tipo de letra. En ning�n caso las fuentes se pueden utilizar por m�s de una empresa con una sola licencia.

En el caso de necesitar una licencia para una red de ordenadores pongase en contacto con el autor.

Todos los componentes que acompa�an al archivo de descarga son propiedad de Fernando Haro y no pueden ser desmontados, modificados, utilizados, distribuidos o copiados de ninguna manera.

Este Acuerdo constituye la declaraci�n completa del acuerdo entre las partes sobre la materia, y se fusiona y sustituye a todos los dem�s o entendimientos previos, �rdenes de compra, acuerdos y arreglos.

El presente Acuerdo se regir� por las leyes de Espa�a. Fernando Haro es el propietario de los derechos de autor de las fuentes, todos sus derivados, el nombre y los materiales que se acompa�an son propiedad exclusiva de Fernando Haro.

Usted no podr� vender, alquilar, arrendar, transferir, modificar, traducir, aplicar ingenier�a inversa, decompilar, desensamblar o crear trabajos comerciales con los tipos de letra.
========================================
Si necesita m�s informaci�n contacte con el dise�ador:
For further information, please contact designer:
========================================
Fernando Haro
fernando@defharo.es
www.defharo.com




